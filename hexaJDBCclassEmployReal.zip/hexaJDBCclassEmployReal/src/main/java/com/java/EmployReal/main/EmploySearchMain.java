package com.java.EmployReal.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.EmployReal.Dao.EmployDao;
import com.java.EmployReal.Dao.EmployDaoImpl;
import com.java.EmployReal.model.Employ;

public class EmploySearchMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the employ no : ");
		int empno = sc.nextInt();
		EmployDao dao = new EmployDaoImpl();
		try {
			Employ employ = dao.searchEmployDao(empno);
			if(employ != null)
				System.out.println(employ);
			else
				System.out.println("Employ with Empno "+empno+" does not exist");
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

}
