package com.java.EmployReal.main;

import java.sql.SQLException;
import java.util.List;

import com.java.EmployReal.Dao.EmployDao;
import com.java.EmployReal.Dao.EmployDaoImpl;
import com.java.EmployReal.model.Employ;



public class EmployShowMain {

	public static void main(String[] args) {
		
		EmployDao dao = new EmployDaoImpl();
		try {
			List<Employ> employList = dao.showEmployDao();
			for(Employ employ : employList)
				System.out.println(employ);
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

}
