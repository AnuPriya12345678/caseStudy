package com.java.EmployReal.util;

import java.util.ResourceBundle;

public class DBPropertyUtil {
	
	public static String getConnectonString(String propertyFileName)
	{
		ResourceBundle rb = ResourceBundle.getBundle(propertyFileName);
		String connectionString = rb.getString("url");
		return connectionString;
	}

}
