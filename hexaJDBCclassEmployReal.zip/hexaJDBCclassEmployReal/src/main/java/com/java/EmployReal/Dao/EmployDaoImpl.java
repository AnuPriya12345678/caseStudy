package com.java.EmployReal.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import com.java.EmployReal.model.Employ;
import com.java.EmployReal.model.Gender;
import com.java.EmployReal.util.DBConnUtil;
import com.java.EmployReal.util.DBPropertyUtil;

public class EmployDaoImpl implements EmployDao {
	
	Connection con;
	PreparedStatement pst;

	@Override
	public List<Employ> showEmployDao() throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM employ";
		pst = con.prepareStatement(query);
		ResultSet rs = pst.executeQuery();
		List<Employ> employList = new ArrayList<Employ> ();
		Employ employ = null;
		while(rs.next())
		{
			employ = new Employ();
			employ.setEmpno(rs.getInt("empno"));  //getInt(0)
			employ.setName(rs.getString("name"));
			employ.setGender(Gender.valueOf(rs.getString("gender")));
			employ.setDept(rs.getString("dept"));
			employ.setDesig(rs.getString("desig"));
			employ.setBasic(rs.getDouble("basic"));
			employList.add(employ);
		}
		return employList;
		
	}

	@Override
	public Employ searchEmployDao(int empno) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM employ WHERE empno = ?";
		pst = con.prepareStatement(query);
		pst.setInt(1, empno);
		ResultSet rs = pst.executeQuery();
		Employ employ = null;
		if(rs.next())
		{
			employ = new Employ();
			employ.setEmpno(rs.getInt("empno"));  //getInt(0)
			employ.setName(rs.getString("name"));
			employ.setGender(Gender.valueOf(rs.getString("gender")));
			employ.setDept(rs.getString("dept"));
			employ.setDesig(rs.getString("desig"));
			employ.setBasic(rs.getDouble("basic"));
		}
		return employ;
		
		
	}

	@Override
	public String insertEmployDao(Employ employ) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "INSERT INTO employ VALUES(?,?,?,?,?,?)";
		PreparedStatement pst = con.prepareStatement(query);
		pst.setInt(1, employ.getEmpno());
		pst.setString(2, employ.getName());
		pst.setString(3, employ.getGender().toString());
		pst.setString(4, employ.getDept());
		pst.setString(5, employ.getDesig());
		pst.setDouble(6, employ.getBasic());
		pst.executeUpdate();
		return "Insertion completed";
	}

	@Override
	public String updateEmployDao(int empno, String dept) throws ClassNotFoundException, SQLException {
		
		Employ employ = searchEmployDao(empno);
		if(employ != null)
		{
			String connectionString = DBPropertyUtil.getConnectonString("db");
			con = DBConnUtil.getConnection(connectionString);
			String query = "UPDATE employ SET dept = ? WHERE empno = ?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, dept);
			pst.setInt(2, empno);
			pst.executeUpdate();
			return "Updated the dept value";
		}
		return "Record not found";
		
	}

	@Override
	public String deleteEmployDao(int empno) throws ClassNotFoundException, SQLException {
		
		Employ employ = searchEmployDao(empno);
		if(employ != null)
		{
			String connectionString = DBPropertyUtil.getConnectonString("db");
			con = DBConnUtil.getConnection(connectionString);
			String query = "DELETE FROM employ WHERE empno = ?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, empno);
			pst.executeUpdate();
			return "Deletion completed";
		}
		else
			return "Record not found";
		
	}

}
