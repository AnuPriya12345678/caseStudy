package com.java.EmployReal.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.EmployReal.Dao.EmployDao;
import com.java.EmployReal.Dao.EmployDaoImpl;
import com.java.EmployReal.model.Employ;
import com.java.EmployReal.model.Gender;

public class EmployInsertMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Employ employ = new Employ();
		System.out.println("Enter the empno : ");
		employ.setEmpno(sc.nextInt());
		System.out.println("Enter the employ name : ");
		employ.setName(sc.next());
		System.out.println("Enter the gender : ");
		employ.setGender(Gender.valueOf(sc.next()));
		System.out.println("Enter dept : ");
		employ.setDept(sc.next());
		System.out.println("Enter the desig : ");
		employ.setDesig(sc.next());
		System.out.println("Enter the basic salary : ");
		employ.setBasic(sc.nextDouble());
		
		EmployDao dao = new EmployDaoImpl();
		try {
			System.out.println(dao.insertEmployDao(employ));
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
	}

}
