package com.java.EmployReal.model;

public enum Gender {

	MALE, FEMALE
	
}
