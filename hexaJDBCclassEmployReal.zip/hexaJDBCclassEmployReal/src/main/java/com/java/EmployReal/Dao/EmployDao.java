package com.java.EmployReal.Dao;

import java.sql.SQLException;
import java.util.List;

import com.java.EmployReal.model.Employ;

public interface EmployDao {
	
	List<Employ> showEmployDao() throws ClassNotFoundException, SQLException;
	Employ searchEmployDao(int empno) throws ClassNotFoundException, SQLException;
	String insertEmployDao(Employ employ) throws ClassNotFoundException, SQLException;
	String updateEmployDao(int empno, String dept) throws ClassNotFoundException, SQLException;
	String deleteEmployDao(int empno) throws ClassNotFoundException, SQLException;
}