package com.java.EmployReal.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.EmployReal.Dao.EmployDao;
import com.java.EmployReal.Dao.EmployDaoImpl;

public class EmployDeleteMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the employ no : ");
		int empno = sc.nextInt();
		
		EmployDao dao = new EmployDaoImpl();
		try {
			System.out.println(dao.deleteEmployDao(empno));
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
	}

}
